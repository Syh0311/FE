// 引入 iconfont 样式文件
import './iconfont.css';

function add(x, y) {
  return x + y;
}

console.log(add(1, 2));
console.log(add(2, 2));
