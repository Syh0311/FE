import $ from 'jquery';

// eslint-disable-next-line
console.log($);

export function mul(x, y) {
  return x * y;
}

export function count(x, y) {
  return x - y;
}
